staticlinks.ontowiki
====================

staticlinks.ontowiki is a module on the left sidebar which can be used to provide configurable static links