/**
 * Chart configuration
 *
 * Each key represents the "maximum" number of multiple dimensions which can
 * be represents by one of the items in charts-array. That means, a bar chart
 * which has maximum number of two is also able to display only one dimension.
 */
var CubeViz_ChartConfig = {

    /**
     * No multiple dimensions
     */
    "0": {
        "charts": [
            /**
             * -----------------------------------------------------------------
             */
            {
                "label": "bar",
                "class": "Visualization_HighCharts_Bar",
                "icon": "bar.png",

                "defaultConfig": {
                    "chart": {
                        "renderTo": "container",
                        "type": "bar"
                    },
                    "title": {
                        "align": "left",
                        "color": "#000000"
                    }
                },
                "options": [
                    {
                        "label": "DataLabels",
                        "defaultValue" : [ { "label": "None", "value": "" } ],
                        "values": [
                            { "label": "Yes", "value": "true" }
                        ],
                        "key": "plotOptions.series.dataLabels.enabled",
                        "type": "array"
                    }
                ]
            },
            {
                "label": "column",
                "class": "Visualization_HighCharts_Column",
                "icon": "column.png",
                "defaultConfig": {
                    "chart": {
                        "renderTo": "container",
                        "type": "column"
                    },
                    "title": {
                        "align": "left",
                        "color": "#000000"
                    }
                },
                "options": [
                    {
                        "label": "DataLabels",
                        "defaultValue" : [ { "label": "None", "value": "" } ],
                        "values": [
                            { "label": "Yes", "value": "true" }
                        ],
                        "key": "plotOptions.series.dataLabels.enabled",
                        "type": "array"
                    }
                ]
            },
            {
                "label": "Table",
                "class": "Visualization_CubeViz_Table",
                "icon": "table.png",
                "options": [
                ]
            }
        ]
    },

    /**
     * One multiple dimensions
     */
    "1": {
        "charts": [
            /**
             * -----------------------------------------------------------------
             */
            {
                "label": "bar",
                "class": "Visualization_HighCharts_Bar",
                "icon": "bar.png",

                "defaultConfig": {
                    "chart": {
                        "renderTo": "container",
                        "type": "bar"
                    },
                    "title": {
                        "align": "left",
                        "color": "#000000"
                    }
                },

                "options": [
                    {
                        "label": "Switching axes",
                        "defaultValue" : [ { "label": "No", "value": false } ],
                        "values": [
                            { "label": "Yes", "value": true }
                        ],
                        "key": "_highchart_switchAxes",
                        "type": "array"
                    },
                    {
                        "label": "DataLabels",
                        "defaultValue" : [ { "label": "None", "value": "" } ],
                        "values": [
                            { "label": "Yes", "value": "true" }
                        ],
                        "key": "plotOptions.series.dataLabels.enabled",
                        "type": "array"
                    },
                    {
                        "label": "Scale",
                        "defaultValue" : [ { "label": "Linear", "value": "linear" } ],
                        "values": [
                            { "label": "Logarithmic", "value": "logarithmic" }
                        ],
                        "key": "yAxis.type",
                        "type": "array"
                    }
                ]
            },
            {
                "label": "column",
                "class": "Visualization_HighCharts_Column",
                "icon": "column.png",
                "defaultConfig": {
                    "chart": {
                        "renderTo": "container",
                        "type": "column"
                    },
                    "title": {
                        "align": "left",
                        "color": "#000000"
                    }
                },

                "options": [
                    {
                        /* System default fpr _highchart_switchAxes is false! */
                        "label": "Switching axes",
                        "defaultValue" : [ { "label": "No", "value": false } ],
                        "values": [
                            { "label": "Yes", "value": true }
                        ],
                        "key": "_highchart_switchAxes",
                        "type": "array"
                    },
                    {
                        "label": "DataLabels",
                        "defaultValue" : [ { "label": "None", "value": "" } ],
                        "values": [
                            { "label": "Yes", "value": "true" }
                        ],
                        "key": "plotOptions.series.dataLabels.enabled",
                        "type": "array"
                    },
                    {
                        "label": "Scale",
                        "defaultValue" : [ { "label": "Linear", "value": "linear" } ],
                        "values": [
                            { "label": "Logarithmic", "value": "logarithmic" }
                        ],
                        "key": "yAxis.type",
                        "type": "array"
                    }
                ]
            },

            /**
             * -----------------------------------------------------------------
             */
           {
                "label": "line",
                "class": "Visualization_HighCharts_Line",
                "icon": "line.png",

                "defaultConfig": {
                    "chart": {
                        "renderTo": "container",
                        "type" : "line"
                    },
                    "title": {
                        "align": "left",
                        "color": "#000000"
                    }
                },
                "options": [
                    {
                        "label": "Type",
                        "defaultValue": [ { "label": "Line", "value": "line" } ],
                        "values": [
                            { "label": "Spline", "value": "spline" },
                            { "label": "Scatterplot", "value": "scatter" }
                        ],
                        "key": "chart.type",
                        "type": "array"
                    },
                    {
                        /* System default fpr _highchart_switchAxes is false! */
                        "label": "Switching axes",
                        "defaultValue" : [ { "label": "No", "value": false } ],
                        "values": [
                            { "label": "Yes", "value": true }
                        ],
                        "key": "_highchart_switchAxes",
                        "type": "array"
                    },
                    {
                        "label": "DataLabels",
                        "defaultValue" : [ { "label": "None", "value": "" } ],
                        "values": [
                            { "label": "Yes", "value": "true" }
                        ],
                        "key": "plotOptions.series.dataLabels.enabled",
                        "type": "array"
                    },
                    {
                        "label": "Inverted",
                        "defaultValue" : [ { "label": "None", "value": "" } ],
                        "values": [
                            { "label": "Yes", "value": "true" }
                        ],
                        "key": "chart.inverted",
                        "type": "array"
                    },
                    {
                        "label": "Scale",
                        "defaultValue" : [ { "label": "Linear", "value": "linear" } ],
                        "values": [
                            { "label": "Logarithmic", "value": "logarithmic" }
                        ],
                        "key": "yAxis.type",
                        "type": "array"
                    }
                ]
            },
           {
                "label": "area",
                "class": "Visualization_HighCharts_Area",
                "icon": "area.png",
                "defaultConfig": {
                    "chart": {
                        "renderTo": "container",
                        "type" : "area"
                    },
                    "title": {
                        "align": "left",
                        "color": "#000000"
                    }
                },
                "options": [
                    {
                        "label": "Type",
                        "defaultValue": [ { "label": "Area", "value": "area" } ],
                        "values": [
                            { "label": "AreaSpline", "value": "areaspline" },
                        ],
                        "key": "chart.type",
                        "type": "array"
                    },
                    {
                        /* System default fpr _highchart_switchAxes is false! */
                        "label": "Switching axes",
                        "defaultValue" : [ { "label": "No", "value": false } ],
                        "values": [
                            { "label": "Yes", "value": true }
                        ],
                        "key": "_highchart_switchAxes",
                        "type": "array"
                    },
                    {
                        "label": "DataLabels",
                        "defaultValue" : [ { "label": "None", "value": "" } ],
                        "values": [
                            { "label": "Yes", "value": "true" }
                        ],
                        "key": "plotOptions.series.dataLabels.enabled",
                        "type": "array"
                    },
                    {
                        "label": "Inverted",
                        "defaultValue" : [ { "label": "None", "value": "" } ],
                        "values": [
                            { "label": "Yes", "value": "true" }
                        ],
                        "key": "chart.inverted",
                        "type": "array"
                    },
                    {
                        "label": "Scale",
                        "defaultValue" : [ { "label": "Linear", "value": "linear" } ],
                        "values": [
                            { "label": "Logarithmic", "value": "logarithmic" }
                        ],
                        "key": "yAxis.type",
                        "type": "array"
                    }
                ]
            },

            /**
             * -----------------------------------------------------------------
             */
            {
                "label": "pie",
                "class": "Visualization_HighCharts_Pie",
                "icon": "pie.png",

                "defaultConfig": {
                    "chart": {
                        "renderTo": "container",
                        "type": "pie",
                        "plotShadow": "true"
                    },
                    "title": {
                        "align": "left",
                        "color": "#000000"
                    },
                    "tooltip": {
                        "percentageDecimals": "1"
                    },
                    "plotOptions": {
                        "pie": {
                            "allowPointSelect": "true",
                            "cursor": "pointer",
                            "dataLabels": {
                                "enabled": "false"
                            },
                            "showInLegend": "false"
                        }
                    }
                },

                "options": [
                ]
            },
            /**
             * -----------------------------------------------------------------
             */
            {
                "label": "Table",
                "class": "Visualization_CubeViz_Table",
                "icon": "table.png",
                "options": [
                ]
            }
            /**
             * -----------------------------------------------------------------
             */
        ]
    },

    /**
     * Two multiple dimensions
     */
    "2": {
        "charts": [
            /**
             * -----------------------------------------------------------------
             */
            {
                "label": "bar",
                "class": "Visualization_HighCharts_Bar",
                "icon": "bar.png",

                "defaultConfig": {
                    "chart": {
                        "renderTo": "container",
                        "type": "bar"
                    },
                    "title": {
                        "align": "left",
                        "color": "#000000"
                    },
                    "plotOptions": {
                        "series": {
                            "stacking": null
                        }
                    }
                },
                "options": [
                    {
                        /* System default fpr _highchart_switchAxes is false! */
                        "label": "Switching axes",
                        "defaultValue" : [ { "label": "No", "value": false } ],
                        "values": [
                            { "label": "Yes", "value": true }
                        ],
                        "key": "_highchart_switchAxes",
                        "type": "array"
                    },
                    {
                        "label": "DataLabels",
                        "defaultValue" : [ { "label": "None", "value": "" } ],
                        "values": [
                            { "label": "Yes", "value": "true" }
                        ],
                        "key": "plotOptions.series.dataLabels.enabled",
                        "type": "array"
                    },
                    {
                        "label": "Stacking",
                        "defaultValue": [ { "label": "None", "value": "" } ],
                        "values": [
                            { "label": "Normal", "value": "normal" },
                            { "label": "Percentage", "value": "percent" }
                        ],
                        "key": "plotOptions.series.stacking",
                        "type": "array"
                    },
                    {
                        "label": "Scale",
                        "defaultValue" : [ { "label": "Linear", "value": "linear" } ],
                        "values": [
                            { "label": "Logarithmic", "value": "logarithmic" }
                        ],
                        "key": "yAxis.type",
                        "type": "array"
                    }
                ]
            },
            {
                "label": "column",
                "class": "Visualization_HighCharts_Column",
                "icon": "column.png",

                "defaultConfig": {
                    "chart": {
                        "renderTo": "container",
                        "type": "column"
                    },
                    "title": {
                        "align": "left",
                        "color": "#000000"
                    },
                    "plotOptions": {
                        "series": {
                            "stacking": null
                        }
                    }
                },

                "options": [
                    {
                        /* System default fpr _highchart_switchAxes is false! */
                        "label": "Switching axes",
                        "defaultValue" : [ { "label": "No", "value": false } ],
                        "values": [
                            { "label": "Yes", "value": true }
                        ],
                        "key": "_highchart_switchAxes",
                        "type": "array"
                    },
                    {
                        "label": "DataLabels",
                        "defaultValue" : [ { "label": "None", "value": "" } ],
                        "values": [
                            { "label": "Yes", "value": "true" }
                        ],
                        "key": "plotOptions.series.dataLabels.enabled",
                        "type": "array"
                    },
                    {
                        "label": "Stacking",
                        "defaultValue": [ { "label": "None", "value": "" } ],
                        "values": [
                            { "label": "Normal", "value": "normal" },
                            { "label": "Percentage", "value": "percent" }
                        ],
                        "key": "plotOptions.series.stacking",
                        "type": "array"
                    },
                    {
                        "label": "Scale",
                        "defaultValue" : [ { "label": "Linear", "value": "linear" } ],
                        "values": [
                            { "label": "Logarithmic", "value": "logarithmic" }
                        ],
                        "key": "yAxis.type",
                        "type": "array"
                    }
                ]
            },

            /**
             * -----------------------------------------------------------------
             */
            {
                "label": "polar",
                "class": "Visualization_HighCharts_Polar",
                "icon": "polar.png",

                "defaultConfig": {
                    "chart": {
                        "renderTo": "container",
                        "polar": "true",
                        "type" : "column"
                    },
                    "title": {
                        "align": "left",
                        "color": "#000000"
                    }
                },
                "options": [
                    {
                        "label": "Type",
                        "defaultValue": [ { "label": "Column", "value": "column" } ],
                        "values": [
                            { "label": "Line", "value": "line" },
                            { "label": "Spline", "value": "spline" },
                            { "label": "Area", "value": "area" },
                            { "label": "AreaSpline", "value": "areaspline" },
                            { "label": "Scatter", "value": "scatter" }
                        ],
                        "key": "chart.type",
                        "type": "array"
                    },
                    {
                        /* System default fpr _highchart_switchAxes is false! */
                        "label": "Switching axes",
                        "defaultValue" : [ { "label": "No", "value": false } ],
                        "values": [
                            { "label": "Yes", "value": true }
                        ],
                        "key": "_highchart_switchAxes",
                        "type": "array"
                    },
                    {
                        "label": "Stacking",
                        "defaultValue": [ { "label": "None", "value": "" } ],
                        "values": [
                            { "label": "Normal", "value": "normal" },
                            { "label": "Percentage", "value": "percent" }
                        ],
                        "key": "plotOptions.series.stacking",
                        "type": "array"
                    },
                    {
                        "label": "Scale",
                        "defaultValue" : [ { "label": "Linear", "value": "linear" } ],
                        "values": [
                            { "label": "Logarithmic", "value": "logarithmic" }
                        ],
                        "key": "yAxis.type",
                        "type": "array"
                    }
                ]
            },

            /**
             * -----------------------------------------------------------------
             */
            {
                "label": "line",
                "class": "Visualization_HighCharts_Line",
                "icon": "line.png",

                "defaultConfig": {
                    "chart": {
                        "renderTo": "container"
                    },
                    "title": {
                        "align": "left",
                        "color": "#000000"
                    }
                },

                "options": [
                    {
                        "label": "Type",
                        "defaultValue": [ { "label": "Line", "value": "line" } ],
                        "values": [
                            { "label": "Spline", "value": "spline" },
                            { "label": "Scatterplot", "value": "scatter" }
                        ],
                        "key": "chart.type",
                        "type": "array"
                    },
                    {
                        /* System default fpr _highchart_switchAxes is false! */
                        "label": "Switching axes",
                        "defaultValue" : [ { "label": "No", "value": false } ],
                        "values": [
                            { "label": "Yes", "value": true }
                        ],
                        "key": "_highchart_switchAxes",
                        "type": "array"
                    },
                    {
                        "label": "Stacking",
                        "defaultValue": [ { "label": "None", "value": "" } ],
                        "values": [
                            { "label": "Normal", "value": "normal" },
                            { "label": "Percentage", "value": "percent" }
                        ],
                        "key": "plotOptions.series.stacking",
                        "type": "array"
                    },
                    {
                        "label": "DataLabels",
                        "defaultValue" : [ { "label": "None", "value": "" } ],
                        "values": [
                            { "label": "Yes", "value": "true" }
                        ],
                        "key": "plotOptions.series.dataLabels.enabled",
                        "type": "array"
                    },
                    {
                        "label": "Inverted",
                        "defaultValue" : [ { "label": "None", "value": "" } ],
                        "values": [
                            { "label": "Yes", "value": "true" }
                        ],
                        "key": "chart.inverted",
                        "type": "array"
                    },
                    {
                        "label": "Scale",
                        "defaultValue" : [ { "label": "Linear", "value": "linear" } ],
                        "values": [
                            { "label": "Logarithmic", "value": "logarithmic" }
                        ],
                        "key": "yAxis.type",
                        "type": "array"
                    }
                ]
            },
            {
                "label": "area",
                "class": "Visualization_HighCharts_Area",
                "icon": "area.png",

                "defaultConfig": {
                    "chart": {
                        "renderTo": "container",
                        "type" : "area"
                    },
                    "title": {
                        "align": "left",
                        "color": "#000000"
                    }
                },

                "options": [
                    {
                        "label": "Type",
                        "defaultValue": [ { "label": "Area", "value": "area" } ],
                        "values": [
                            { "label": "AreaSpline", "value": "areaspline" }
                        ],
                        "key": "chart.type",
                        "type": "array"
                    },
                    {
                        /* System default fpr _highchart_switchAxes is false! */
                        "label": "Switching axes",
                        "defaultValue" : [ { "label": "No", "value": false } ],
                        "values": [
                            { "label": "Yes", "value": true }
                        ],
                        "key": "_highchart_switchAxes",
                        "type": "array"
                    },
                    {
                        "label": "Stacking",
                        "defaultValue": [ { "label": "None", "value": "" } ],
                        "values": [
                            { "label": "Normal", "value": "normal" },
                            { "label": "Percentage", "value": "percent" }
                        ],
                        "key": "plotOptions.series.stacking",
                        "type": "array"
                    },
                    {
                        "label": "DataLabels",
                        "defaultValue" : [ { "label": "None", "value": "" } ],
                        "values": [
                            { "label": "Yes", "value": "true" }
                        ],
                        "key": "plotOptions.series.dataLabels.enabled",
                        "type": "array"
                    },
                    {
                        "label": "Inverted",
                        "defaultValue" : [ { "label": "None", "value": "" } ],
                        "values": [
                            { "label": "Yes", "value": "true" }
                        ],
                        "key": "chart.inverted",
                        "type": "array"
                    },
                    {
                        "label": "Scale",
                        "defaultValue" : [ { "label": "Linear", "value": "linear" } ],
                        "values": [
                            { "label": "Logarithmic", "value": "logarithmic" }
                        ],
                        "key": "yAxis.type",
                        "type": "array"
                    }
                ]
            },

            /**
             * -----------------------------------------------------------------
             */
            {
                "label": "Table",
                "class": "Visualization_CubeViz_Table",
                "icon": "table.png",
                "options": [
                ]
            }
        ]
    }
}; 
