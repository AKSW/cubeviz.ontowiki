## Example model

Simple component and module which creates a new knowledge base with example DataCube information to visualize.
